import cv2
import matplotlib.pyplot as plt
import mmcv
import numpy as np
from matplotlib.patches import Rectangle
from mmocr.apis import TextDetInferencer, TextRecInferencer
import cv2
import torch
from PIL import Image, ImageDraw, ImageFont, ImageOps
from transformers import AutoProcessor, LayoutLMv3ForTokenClassification

#Prepare model
DBNET_IC15 = TextDetInferencer(model='mmocr/configs/textdet/dbnet/dbnet_resnet50-dcnv2_fpnc_1200e_icdar2015.py', weights='epoch_50_det.pth')
SVTR_SYNTH = TextRecInferencer(model='mmocr/configs/textrecog/svtr/svtr-base_20e_st_mj.py', weights='epoch_50_rec.pth')
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
ser_processor = AutoProcessor.from_pretrained(
    "aruca/ser-model-microsoft", apply_ocr=False
)
ser_model = LayoutLMv3ForTokenClassification.from_pretrained(
    "aruca/ser-model-microsoft"
)
ser_model.to(device)
id2label = ser_model.config.id2label

# Preprocess Image
from PIL import Image, ImageOps
IMAGE_TEST = "test/q5.jpeg"
TARGET_WIDTH = 1024  # Set your target width
image = Image.open(IMAGE_TEST)
image = ImageOps.exif_transpose(image)
wpercent = TARGET_WIDTH / image.size[0]
hsize = int(image.size[1] * wpercent)
image = image.resize((TARGET_WIDTH, hsize), Image.LANCZOS)
width, height = image.size
# Convert the resized image back to numpy array
resized_img = mmcv.rgb2bgr(np.array(image))

# Perform text detection on the resized image
det_result = DBNET_IC15(resized_img)
polys_raw = det_result["predictions"][0]["polygons"]
polys = []
for poly in polys_raw:
  c = np.array(poly).astype(int).reshape((-1, 2))
  rect = cv2.minAreaRect(c)
  box = cv2.boxPoints(rect)
  polys.append(box)
fig, ax = plt.subplots()
ax.imshow(resized_img)
for poly in polys:
  c = np.concatenate((poly, poly[0].reshape((-1, 2))))
  ax.plot(c[:, 0], c[:, 1], linewidth=2)
ax.axis("off")
plt.show()

# Read detected text from top left to bottom right
tolerance = 30  # You can adjust this value based on your needs
rows = {}
for poly in polys:
    y = np.mean(poly[:, 1])  # Use mean y-coordinate as the key
    added_to_existing_row = False
    # Check if the polygon can be added to an existing row within tolerance
    for existing_row_key in rows:
        if abs(y - existing_row_key) < tolerance:
            rows[existing_row_key].append(poly)
            added_to_existing_row = True
            break
    # If not added to an existing row, create a new row
    if not added_to_existing_row:
        rows[y] = [poly]
# Sort within each row based on x-coordinates
for row_key in rows:
    rows[row_key] = sorted(rows[row_key], key=lambda poly: poly[0, 0])
# Sort rows based on the y-coordinates of the first polygon in each row
sorted_rows = sorted(rows.items(), key=lambda item: item[0])
combined = []
# Now, sorted_rows contains the grouped and sorted polygons
for row_key, row_polys in sorted_rows:
    for poly in row_polys:
        combined.append(poly)
polys=combined.copy()
def organize_points(rect):
  """
  Sort 4 vertices polygon into the same order
  [top-left, top-right, bottom-right, bottom-left]
  """
  # sort points based on the x coordinate
  # so the order now [left-1, left-2, right-1, right-2]
  # we don't know which one is top or bottom yet
  points = sorted(list(rect), key=lambda x: x[0])
  # for 2 left points
  # the point with smaller y become top-left
  if points[1][1] > points[0][1]:
      index_1 = 0
      index_4 = 1
  else:
      index_1 = 1
      index_4 = 0
  # for 2 right points
  # the point with smaller y become top-right
  if points[3][1] > points[2][1]:
      index_2 = 2
      index_3 = 3
  else:
      index_2 = 3
      index_3 = 2
  return np.array([
      points[index_1], points[index_2], points[index_3], points[index_4]
  ])
def extract_text_image(rect, img):
  """
  Given 4 vertices polygon, crop the image using that
  polygon, and transform the crop so that it is flat.
  """
  # get the top-left, top-right, bottom-right, and bottom-left points.
  rect = organize_points(rect)
  tl, tr, br, bl = rect
  # determine the flattened image width,
  # which is equal to the largest bottom/top side of the polygon
  widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
  widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
  maxWidth = max(int(widthA), int(widthB))
  # determine the flattened image height,
  # which is equal to the largest left/right side of the polygon
  heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
  heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
  maxHeight = max(int(heightA), int(heightB))
  # create the 4 vertices polygon after transformation
  dst = np.array(
    [
      [0, 0],
      [maxWidth - 1, 0],
      [maxWidth - 1, maxHeight - 1],
      [0, maxHeight - 1],
    ],
    dtype=np.float32,
  )
  # do the transformation
  M = cv2.getPerspectiveTransform(rect, dst)
  return cv2.warpPerspective(img, M, (maxWidth, maxHeight))
text_images = [extract_text_image(poly, resized_img) for poly in polys]

# Perform text recognition on the resized image
text_images = []
texts = []
for poly in polys:
  poly_arr = np.array(poly).reshape((-1, 2)).astype(np.float32)
  txt_img = extract_text_image(poly_arr, resized_img)
  rec_result = SVTR_SYNTH(txt_img)
  text_images.append(txt_img)
  texts.append(rec_result["predictions"][0]["text"])
import Levenshtein as lev
import string
# Load the ground truth from q5.txt
with open('full-text/q5.txt', 'r') as file:
    ground_truth = file.read().lower().translate(str.maketrans('', '', string.punctuation)).split()
# Convert recognized texts to a single string
recognized_text = ' '.join(texts)
# Convert ground truth to a single string
ground_truth_text = ' '.join(ground_truth)
from autocorrect import Speller
spell = Speller()
recognized_text=spell(recognized_text)
# Remove all occurrences of <UK>
recognized_text = recognized_text.replace('<UK>', '')
# Retrieve the new list of texts from the autocorrected recognized_text
texts=recognized_text.split()
# Calculate Character Error Rate (CER)
cer = lev.distance(ground_truth_text, recognized_text) / max(len(ground_truth_text), len(recognized_text))
# Calculate Word Error Rate (WER)
wer = lev.distance(ground_truth, texts) / max(len(ground_truth), len(texts))
print(f'recognized text:{recognized_text}')
print(f"CER: {cer:.4f}")
print(f"WER: {wer:.4f}")

# Perform Semantic Entity Recognition on the resized image
# Combine polys and texts into ocr_results format
combined_results = []
for poly, text in zip(polys, texts):
    # Extract coordinates from poly
    coordinates = poly.astype(int).tolist()
    # Create the entry in the format of ocr_results
    entry = (coordinates, text, 1.0)
    combined_results.append(entry)
def normalize_box(bbox, width, height):
    # xyxy
    return [
        int(bbox[0] / width * 1000),
        int(bbox[1] / height * 1000),
        int(bbox[2] / width * 1000),
        int(bbox[3] / height * 1000),
    ]
def prepare_bbox(bbox, width, height):
    bbox_np = np.array(bbox).reshape((-1, 2))
    x1, x2 = np.min(bbox_np[:, 0]), np.max(bbox_np[:, 0])
    y1, y2 = np.min(bbox_np[:, 1]), np.max(bbox_np[:, 1])
    return normalize_box([x1, y1, x2, y2], width, height)
bboxes = [prepare_bbox(res[0], width, height) for res in combined_results]
texts = [res[1] for res in combined_results]
encoding = ser_processor(
    image,
    texts,
    boxes=bboxes,
    return_offsets_mapping=True,
    return_tensors="pt"
)
offset_mapping = encoding.pop('offset_mapping')
for k,v in encoding.items():
  encoding[k] = v.to(device)
outputs = ser_model(**encoding)
# get the label with max logits
predictions = outputs.logits.argmax(-1).squeeze().tolist()
# get the bounding box
token_boxes = encoding.bbox.squeeze().tolist()
def unnormalize_box(bbox, width, height):
    return [
        width * (bbox[0] / 1000),
        height * (bbox[1] / 1000),
        width * (bbox[2] / 1000),
        height * (bbox[3] / 1000),
    ]
# filter out predictions and boxes that are subword
is_subword = np.array(offset_mapping.squeeze().tolist())[:,0] != 0
true_predictions = [id2label[pred] for idx, pred in enumerate(predictions) if not is_subword[idx]]
true_boxes = [unnormalize_box(box, width, height) for idx, box in enumerate(token_boxes) if not is_subword[idx]]
vis = image.copy()
draw = ImageDraw.Draw(vis)
font = ImageFont.truetype("Arial.ttf", 10)
for prediction, box in zip(true_predictions, true_boxes):
    draw.rectangle(box, outline="blue")
    draw.text((box[0]+10, box[1]-10), text=prediction, font=font, fill="blue")
vis.save("ser.png")